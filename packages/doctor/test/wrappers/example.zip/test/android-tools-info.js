"use strict";
const android_tools_info_1 = require('../lib/android-tools-info');
const os_1 = require('os');
const chai_1 = require("chai");
const helpers_1 = require('../lib/helpers');
const constants_1 = require('../lib/constants');
describe("androidToolsInfo", () => {
    const defaultAdditionalInformation = "You will not be able to build your projects for Android." + os_1.EOL
        + "To be able to build for Android, verify that you have installed The Java Development Kit (JDK) and configured it according to system requirements as" + os_1.EOL +
        " described in " + constants_1.Constants.SYSTEM_REQUIREMENTS_LINKS[process.platform];
    const getAndroidToolsInfo = (runtimeVersion) => {
        const childProcess = {};
        const fs = {
            exists: () => true,
            execSync: () => null,
            readJson: () => {
                return runtimeVersion ? {
                    nativescript: {
                        "tns-android": {
                            version: runtimeVersion
                        }
                    }
                } : null;
            }
        };
        const hostInfo = {};
        const helpers = new helpers_1.Helpers({});
        return new android_tools_info_1.AndroidToolsInfo(childProcess, fs, hostInfo, helpers);
    };
    describe("validateJavacVersion", () => {
        const testData = [
            {
                javacVersion: "1.8.0"
            },
            {
                javacVersion: "1.8.0_152"
            },
            {
                javacVersion: "9"
            },
            {
                javacVersion: "9.0.1"
            },
            {
                javacVersion: "10"
            },
            {
                javacVersion: "10.0.1"
            },
            {
                javacVersion: "1.7.0",
                warnings: ["Javac version 1.7.0 is not supported. You have to install at least 1.8.0."]
            },
            {
                javacVersion: "1.7.0_132",
                warnings: ["Javac version 1.7.0_132 is not supported. You have to install at least 1.8.0."]
            },
            {
                javacVersion: null,
                warnings: ["Error executing command 'javac'. Make sure you have installed The Java Development Kit (JDK) and set JAVA_HOME environment variable."]
            },
            {
                javacVersion: "10",
                runtimeVersion: "4.0.0",
                warnings: [`The Java compiler version 10 is not compatible with the current Android runtime version 4.0.0. ` +
                        `In order to use this Javac version, you need to update your Android runtime or downgrade your Java compiler version.`],
                additionalInformation: "You will not be able to build your projects for Android." + os_1.EOL +
                    "To be able to build for Android, downgrade your Java compiler version or update your Android runtime."
            },
            {
                javacVersion: "10",
                runtimeVersion: "4.2.0"
            }
        ];
        testData.forEach(({ javacVersion, warnings, runtimeVersion, additionalInformation }) => {
            it(`returns correct result when version is ${javacVersion}`, () => {
                const androidToolsInfo = getAndroidToolsInfo(runtimeVersion);
                const actualWarnings = androidToolsInfo.validateJavacVersion(javacVersion, "/Users/username/projectDir");
                let expectedWarnings = [];
                if (warnings && warnings.length) {
                    expectedWarnings = warnings.map(warning => {
                        return {
                            platforms: [constants_1.Constants.ANDROID_PLATFORM_NAME],
                            warning,
                            additionalInformation: additionalInformation || defaultAdditionalInformation
                        };
                    });
                }
                chai_1.assert.deepEqual(actualWarnings, expectedWarnings);
            });
        });
        const npmTagsTestData = [
            {
                javacVersion: "1.8.0",
                runtimeVersion: "rc"
            },
            {
                javacVersion: "10",
                runtimeVersion: "rc"
            },
            {
                javacVersion: "10",
                runtimeVersion: "latest",
                warnings: [`The Java compiler version 10 is not compatible with the current Android runtime version 4.0.0. ` +
                        `In order to use this Javac version, you need to update your Android runtime or downgrade your Java compiler version.`],
                additionalInformation: "You will not be able to build your projects for Android." + os_1.EOL +
                    "To be able to build for Android, downgrade your Java compiler version or update your Android runtime."
            },
            {
                javacVersion: "10",
                runtimeVersion: "old",
                warnings: [`The Java compiler version 10 is not compatible with the current Android runtime version 4.1.0-2018.5.17.1. ` +
                        `In order to use this Javac version, you need to update your Android runtime or downgrade your Java compiler version.`],
                additionalInformation: "You will not be able to build your projects for Android." + os_1.EOL +
                    "To be able to build for Android, downgrade your Java compiler version or update your Android runtime."
            },
            {
                javacVersion: "10",
                runtimeVersion: "old",
                warnings: [`The Java compiler version 10 is not compatible with the current Android runtime version 4.1.0-2018.5.17.1. ` +
                        `In order to use this Javac version, you need to update your Android runtime or downgrade your Java compiler version.`],
                additionalInformation: "You will not be able to build your projects for Android." + os_1.EOL +
                    "To be able to build for Android, downgrade your Java compiler version or update your Android runtime."
            },
            {
                javacVersion: "1.8.0",
                runtimeVersion: "latest"
            },
            {
                javacVersion: "1.8.0",
                runtimeVersion: "old"
            },
        ];
        npmTagsTestData.forEach(({ javacVersion, warnings, runtimeVersion, additionalInformation }) => {
            it(`returns correct result when javac version is ${javacVersion} and the runtime version is tag from npm: ${runtimeVersion}`, () => {
                let execSyncCommand = null;
                const childProcess = {
                    execSync: (command) => {
                        execSyncCommand = command;
                        return JSON.stringify({
                            latest: '4.0.0',
                            rc: '4.1.0-rc-2018.5.21.1',
                            next: '4.1.0-2018.5.23.2',
                            old: '4.1.0-2018.5.17.1'
                        });
                    }
                };
                const fs = {
                    exists: (filePath) => true,
                    execSync: () => null,
                    readJson: () => ({
                        nativescript: {
                            "tns-android": {
                                version: runtimeVersion
                            }
                        }
                    })
                };
                const hostInfo = {};
                const helpers = new helpers_1.Helpers({});
                const androidToolsInfo = new android_tools_info_1.AndroidToolsInfo(childProcess, fs, hostInfo, helpers);
                const actualWarnings = androidToolsInfo.validateJavacVersion(javacVersion, "/Users/username/projectDir");
                let expectedWarnings = [];
                if (warnings && warnings.length) {
                    expectedWarnings = warnings.map(warning => {
                        return {
                            platforms: [constants_1.Constants.ANDROID_PLATFORM_NAME],
                            warning,
                            additionalInformation: additionalInformation || defaultAdditionalInformation
                        };
                    });
                }
                chai_1.assert.deepEqual(actualWarnings, expectedWarnings);
                chai_1.assert.equal(execSyncCommand, "npm view tns-android dist-tags --json");
            });
        });
    });
});
//# sourceMappingURL=android-tools-info.js.map