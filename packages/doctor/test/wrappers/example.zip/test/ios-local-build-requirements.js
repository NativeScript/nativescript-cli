"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const ios_local_build_requirements_1 = require("../lib/local-build-requirements/ios-local-build-requirements");
const chai_1 = require("chai");
const constants_1 = require("../lib/constants");
describe("iOSLocalBuildRequirements", () => {
    const setupTestCase = (results) => {
        const sysInfo = {
            getXcodeVersion: () => __awaiter(this, void 0, void 0, function* () { return results.hasOwnProperty("getXcodeVersion") ? results.getXcodeVersion : "10.0"; }),
            getXcodeprojLocation: () => __awaiter(this, void 0, void 0, function* () { return results.hasOwnProperty("getXcodeprojLocation") ? results.getXcodeprojLocation : "path to xcodeproj"; }),
        };
        const hostInfo = {
            isDarwin: results.hasOwnProperty("isDarwin") ? results.isDarwin : true
        };
        const iOSLocalBuildRequirements = new ios_local_build_requirements_1.IosLocalBuildRequirements(sysInfo, hostInfo);
        return iOSLocalBuildRequirements;
    };
    describe("isXcodeVersionValid", () => {
        const testCases = [
            {
                testName: "returns false when Xcode is not installed",
                getXcodeVersion: null,
                expectedResult: false
            },
            {
                testName: "returns false when Xcode's major version is below min required version",
                getXcodeVersion: "10.0",
                minRequiredXcodeVersion: 11,
                expectedResult: false
            },
            {
                testName: "returns true when Xcode's major version equals min required version",
                getXcodeVersion: "10.0",
                minRequiredXcodeVersion: 10,
                expectedResult: true
            },
            {
                testName: "returns true when Xcode's major version equals min required version",
                getXcodeVersion: "12.0",
                minRequiredXcodeVersion: 10,
                expectedResult: true
            }
        ];
        testCases.forEach(testCase => {
            it(testCase.testName, () => __awaiter(this, void 0, void 0, function* () {
                const iOSLocalBuildRequirements = setupTestCase(testCase);
                let originalXcodeVersion = constants_1.Constants.XCODE_MIN_REQUIRED_VERSION;
                constants_1.Constants.XCODE_MIN_REQUIRED_VERSION = testCase.minRequiredXcodeVersion || constants_1.Constants.XCODE_MIN_REQUIRED_VERSION;
                const isXcodeVersionValid = yield iOSLocalBuildRequirements.isXcodeVersionValid();
                // Get back the XCODE_MIN_REQUIRED_VERSION value.
                constants_1.Constants.XCODE_MIN_REQUIRED_VERSION = originalXcodeVersion;
                chai_1.assert.equal(isXcodeVersionValid, testCase.expectedResult);
            }));
        });
    });
    describe("checkRequirements", () => {
        const testCases = [
            {
                testName: "returns false when OS is not macOS",
                isDarwin: false,
                expectedResult: false
            },
            {
                testName: "returns false when Xcode is not installed",
                getXcodeVersion: null,
                expectedResult: false
            },
            {
                testName: "returns false when Xcode's major version is below min required version",
                getXcodeVersion: "10.0",
                minRequiredXcodeVersion: 11,
                expectedResult: false
            },
            {
                testName: "returns false when xcodeproj is not installed",
                getXcodeprojLocation: null,
                expectedResult: false
            },
            {
                testName: "returns true when Xcode's major version equals min required version",
                getXcodeVersion: "10.0",
                minRequiredXcodeVersion: 10,
                expectedResult: true
            },
            {
                testName: "returns true when Xcode's major version equals min required version",
                getXcodeVersion: "12.0",
                minRequiredXcodeVersion: 10,
                expectedResult: true
            }
        ];
        testCases.forEach(testCase => {
            it(testCase.testName, () => __awaiter(this, void 0, void 0, function* () {
                const iOSLocalBuildRequirements = setupTestCase(testCase);
                let originalXcodeVersion = constants_1.Constants.XCODE_MIN_REQUIRED_VERSION;
                constants_1.Constants.XCODE_MIN_REQUIRED_VERSION = testCase.minRequiredXcodeVersion || constants_1.Constants.XCODE_MIN_REQUIRED_VERSION;
                const isXcodeVersionValid = yield iOSLocalBuildRequirements.checkRequirements();
                // Get back the XCODE_MIN_REQUIRED_VERSION value.
                constants_1.Constants.XCODE_MIN_REQUIRED_VERSION = originalXcodeVersion;
                chai_1.assert.equal(isXcodeVersionValid, testCase.expectedResult);
            }));
        });
    });
});
//# sourceMappingURL=ios-local-build-requirements.js.map