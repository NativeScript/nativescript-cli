"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const android_local_build_requirements_1 = require('../lib/local-build-requirements/android-local-build-requirements');
const chai_1 = require("chai");
describe("androidLocalBuildRequirements", () => {
    describe("checkRequirements", () => {
        const setupTestCase = (results) => {
            const androidToolsInfo = {
                validateInfo: () => results.validateInfo || [],
                validateAndroidHomeEnvVariable: () => [],
                getToolsInfo: () => null,
                validateJavacVersion: (installedJavaVersion, projectDir, runtimeVersion) => results.validateJavacVersion || [],
                getPathToAdbFromAndroidHome: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getPathToEmulatorExecutable: () => undefined
            };
            const sysInfo = {
                getJavaCompilerVersion: () => __awaiter(this, void 0, void 0, function* () { return results.hasOwnProperty("getJavaCompilerVersion") ? results.getJavaCompilerVersion : "8.0.0"; }),
                getAdbVersion: (pathToAdb) => __awaiter(this, void 0, void 0, function* () { return results.hasOwnProperty("getAdbVersion") ? results.getAdbVersion : "1.0.39"; }),
                getXcodeVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getNodeVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getNpmVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getNodeGypVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getXcodeprojLocation: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                isITunesInstalled: () => __awaiter(this, void 0, void 0, function* () { return false; }),
                getCocoaPodsVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getOs: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                isAndroidInstalled: () => __awaiter(this, void 0, void 0, function* () { return false; }),
                getMonoVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getGitVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getGitPath: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getGradleVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                isCocoaPodsWorkingCorrectly: () => __awaiter(this, void 0, void 0, function* () { return false; }),
                getNativeScriptCliVersion: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
                getXcprojInfo: () => __awaiter(this, void 0, void 0, function* () { return null; }),
                isCocoaPodsUpdateRequired: () => __awaiter(this, void 0, void 0, function* () { return true; }),
                isAndroidSdkConfiguredCorrectly: () => __awaiter(this, void 0, void 0, function* () { return true; }),
                getSysInfo: (config) => __awaiter(this, void 0, void 0, function* () { return null; }),
                setShouldCacheSysInfo: (shouldCache) => undefined
            };
            const androidLocalBuildRequirements = new android_local_build_requirements_1.AndroidLocalBuildRequirements(androidToolsInfo, sysInfo);
            return androidLocalBuildRequirements;
        };
        it("returns true when everything is setup correctly", () => __awaiter(this, void 0, void 0, function* () {
            const androidLocalBuildRequirements = setupTestCase({ testName: "returns true when everything is setup correctly" });
            const result = yield androidLocalBuildRequirements.checkRequirements();
            chai_1.assert.isTrue(result);
        }));
        describe("returns false", () => {
            const getWarnings = () => {
                return [{
                        warning: "warning",
                        additionalInformation: "additional info",
                        platforms: ["android"]
                    }];
            };
            const testData = [
                {
                    testName: "when java is not installed",
                    getJavaCompilerVersion: null
                },
                {
                    testName: "when java is installed, but it is not compatible for current project",
                    validateJavacVersion: getWarnings()
                },
                {
                    testName: "when Android tools are not installed correctly",
                    validateInfo: getWarnings()
                },
                {
                    testName: "when adb cannot be found",
                    getAdbVersion: null
                }
            ];
            testData.forEach(testCase => {
                it(testCase.testName, () => __awaiter(this, void 0, void 0, function* () {
                    const androidLocalBuildRequirements = setupTestCase(testCase);
                    const result = yield androidLocalBuildRequirements.checkRequirements();
                    chai_1.assert.isFalse(result);
                }));
            });
        });
    });
});
//# sourceMappingURL=android-local-build-requirements.js.map