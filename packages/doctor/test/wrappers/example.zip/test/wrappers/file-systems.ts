import { FileSystem } from "../../lib/wrappers/file-system";
import { tmpdir } from "os";

describe('FileSystem', () => {
    describe('extractZip', () => {
        const tmpDir =
        let testFilePath: string;
        before(() => {
            testFilePath = genTestFile();
        });

        it('should extract zip archive in the specified folder as stored in file', () => {

        });
    })
});

function genTestFile(): string {

}