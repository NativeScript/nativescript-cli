import { tmpdir } from "os";
import { assert } from "chai";
import { unlinkSync } from "fs";

import { FileSystem } from "../../lib/wrappers/file-system";

describe('FileSystem', () => {
    describe('extractZip', () => {
        const d = new Date();
        const datetime = [
            d.getFullYear(),
            d.getMonth() + 1,
            d.getDate(),
            d.getHours(),
            d.getMinutes(),
            d.getSeconds(),
            d.getMilliseconds()
        ].join('');
        const tmpDir = `${tmpdir()}/${datetime}`;
        const testFilePath = `${__dirname}/example.zip`;
        const filesThatNeedToExtsit = [
            `${tmpDir}/test/android-local-build-requirements.js`,
            `${tmpDir}/test/android-local-build-requirements.js.map`,
            `${tmpDir}/test/android-local-build-requirements.ts`,
            `${tmpDir}/test/android-tools-info.js`,
            `${tmpDir}/test/android-tools-info.js.map`,
            `${tmpDir}/test/android-tools-info.ts`,
            `${tmpDir}/test/ios-local-build-requirements.js`,
            `${tmpDir}/test/ios-local-build-requirements.js.map`,
            `${tmpDir}/test/ios-local-build-requirements.ts`,
            `${tmpDir}/test/sys-info.js`,
            `${tmpDir}/test/sys-info.js.map`,
            `${tmpDir}/test/sys-info.ts`,
            `${tmpDir}/test/wrappers/file-systems.ts`,
        ];

        it('should extract zip archive in the specified folder as stored in example file', done => {
            const fs  = new FileSystem();

            fs.extractZip(testFilePath, tmpDir)
                .then(() => {
                    const allExists = filesThatNeedToExtsit
                        .map(fs.exists)
                        .reduce((acc, r) => acc && r, true);

                    assert.isTrue(allExists);

                    done();
                })
                .catch(e => done(e));
        });

        afterEach(() => filesThatNeedToExtsit.forEach(unlinkSync));
    })
});
