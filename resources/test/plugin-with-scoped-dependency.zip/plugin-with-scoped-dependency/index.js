require("@scoped-plugin/inner-plugin");
console.log("plugin-with-scoped-dependency index.js");