const Observable = require("tns-core-modules/data/observable").Observable;
console.time("console.time");

function getMessage(counter) {
    if (counter <= 0) {
        return "Hoorraaay! You unlocked the NativeScript clicker achievement!";
    } else {
        return `${counter} taps left`;
    }
}

function createViewModel() {
    const viewModel = new Observable();
    viewModel.counter = 42;
    viewModel.message = getMessage(viewModel.counter);

    viewModel.onTap = () => {
        console.log("console.log onTap");

        console.dir({
            level0_0: {
                level1_0: {
                    level2: "value"
                },
                level1_1: {
                    level2: "value2"
                }
            },
            level0_1: {
                level1_0: "value3"
            }
        });

        console.log(`multiline
        message
        from
        console.log`);

        console.trace("console.trace onTap");

        console.timeEnd("console.time");

        throw new Error("Error in onTap");
    };

    return viewModel;
}

exports.createViewModel = createViewModel;
